import { NextRequest, NextResponse } from 'next/server';
import { getSessionFromCookie } from '@/lib/session';
import { db } from '@/lib/db';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ conversationId: string }> }
) {
  try {
    const session = await getSessionFromCookie();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { conversationId } = await params;

    const conversation = await db.conversation.findFirst({
      where: { id: conversationId, userId: session.userId },
      include: {
        messages: {
          orderBy: { createdAt: 'asc' },
        },
      },
    });

    if (!conversation) {
      return NextResponse.json(
        { error: 'Conversation not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ conversation });
  } catch (error) {
    console.error('Get messages error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch messages' },
      { status: 500 }
    );
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ conversationId: string }> }
) {
  try {
    const session = await getSessionFromCookie();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { conversationId } = await params;
    const { content, role, imageUrl, imagePrompt, audioUrl } = await req.json();

    // Verify conversation belongs to user
    const conversation = await db.conversation.findFirst({
      where: { id: conversationId, userId: session.userId },
    });

    if (!conversation) {
      return NextResponse.json(
        { error: 'Conversation not found' },
        { status: 404 }
      );
    }

    const message = await db.message.create({
      data: {
        content,
        role: role || 'user',
        conversationId,
        imageUrl: imageUrl || null,
        imagePrompt: imagePrompt || null,
        audioUrl: audioUrl || null,
      },
    });

    return NextResponse.json({ message }, { status: 201 });
  } catch (error) {
    console.error('Create message error:', error);
    return NextResponse.json(
      { error: 'Failed to create message' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ conversationId: string }> }
) {
  try {
    const session = await getSessionFromCookie();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { conversationId } = await params;
    const body = await req.json();

    // Verify conversation belongs to user
    const existing = await db.conversation.findFirst({
      where: { id: conversationId, userId: session.userId },
    });

    if (!existing) {
      return NextResponse.json(
        { error: 'Conversation not found' },
        { status: 404 }
      );
    }

    // Handle message content editing
    if (body.messageId && body.content !== undefined) {
      const { messageId, content } = body;

      if (typeof content !== 'string' || content.trim().length === 0) {
        return NextResponse.json(
          { error: 'Content is required and must be a non-empty string' },
          { status: 400 }
        );
      }

      const message = await db.message.findFirst({
        where: { id: messageId, conversationId, conversation: { userId: session.userId } },
      });

      if (!message) {
        return NextResponse.json(
          { error: 'Message not found' },
          { status: 404 }
        );
      }

      const updatedMessage = await db.message.update({
        where: { id: messageId },
        data: { content: content.trim() },
      });

      return NextResponse.json({ message: updatedMessage });
    }

    // Handle conversation title rename
    const { title } = body;
    if (!title || typeof title !== 'string' || title.trim().length === 0) {
      return NextResponse.json(
        { error: 'Title is required and must be a non-empty string' },
        { status: 400 }
      );
    }

    const trimmedTitle = title.trim().slice(0, 100);

    const conversation = await db.conversation.update({
      where: { id: conversationId },
      data: { title: trimmedTitle },
    });

    return NextResponse.json({ conversation });
  } catch (error) {
    console.error('Update conversation/message error:', error);
    return NextResponse.json(
      { error: 'Failed to update' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ conversationId: string }> }
) {
  try {
    const session = await getSessionFromCookie();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { conversationId } = await params;

    await db.conversation.deleteMany({
      where: { id: conversationId, userId: session.userId },
    });

    return NextResponse.json({ message: 'Conversation deleted' });
  } catch (error) {
    console.error('Delete conversation error:', error);
    return NextResponse.json(
      { error: 'Failed to delete conversation' },
      { status: 500 }
    );
  }
}
