'use client';

import { useChatStore, Conversation } from '@/store/chat-store';
import { useAuthStore } from '@/store/auth-store';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Search,
  Trash2,
  MessageSquare,
  LogOut,
  Moon,
  Sun,
  Sparkles,
  X,
  Plus,
  Settings,
  Pin,
  Copy,
  CheckSquare,
  Loader2,
  Check,
  WifiOff,
  BarChart3,
  MessageCircle,
  Hash,
  TrendingUp,
  Calendar,
  UserCircle,
} from 'lucide-react';
import { useTheme } from 'next-themes';
import { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import UserProfileSheet from '@/components/user-profile-sheet';
import { ZinterLogoWithText } from '@/components/zinter-logo';

interface ConversationSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}


function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

type TimeGroup = 'Today' | 'Yesterday' | 'This Week' | 'Older';

function getTimeGroup(dateStr: string): TimeGroup {
  const date = new Date(dateStr);
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfYesterday = new Date(startOfToday.getTime() - 24 * 60 * 60 * 1000);
  const startOfWeek = new Date(startOfToday.getTime() - 7 * 24 * 60 * 60 * 1000);

  if (date >= startOfToday) return 'Today';
  if (date >= startOfYesterday) return 'Yesterday';
  if (date >= startOfWeek) return 'This Week';
  return 'Older';
}

const TIME_GROUP_ORDER: TimeGroup[] = ['Today', 'Yesterday', 'This Week', 'Older'];

function groupConversations(conversations: Conversation[]): Record<TimeGroup, Conversation[]> {
  const groups: Record<TimeGroup, Conversation[]> = {
    Today: [],
    Yesterday: [],
    'This Week': [],
    Older: [],
  };

  for (const conv of conversations) {
    const group = getTimeGroup(conv.updatedAt);
    groups[group].push(conv);
  }

  return groups;
}

function formatTime(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));

  if (days === 0) return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (days === 1) return 'Yesterday';
  if (days < 7) return date.toLocaleDateString([], { weekday: 'short' });
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function getStoredPinned(): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const stored = localStorage.getItem('nexusai-pinned-conversations');
    if (stored) return JSON.parse(stored) as string[];
  } catch {
    // ignore
  }
  return [];
}

function savePinned(pinned: string[]) {
  try {
    localStorage.setItem('nexusai-pinned-conversations', JSON.stringify(pinned));
  } catch {
    // ignore
  }
}

export default function ConversationSidebar({ isOpen, onClose }: ConversationSidebarProps) {
  const {
    conversations,
    activeConversationId,
    setActiveConversationId,
    addConversation,
    deleteConversation,
    updateConversation,
    autoTitleLoadingId,
  } = useChatStore();
  const { user, logout } = useAuthStore();
  const { theme, setTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [logoutDialogOpen, setLogoutDialogOpen] = useState(false);

  const [statsOpen, setStatsOpen] = useState(false);
  const [profileDialogOpen, setProfileDialogOpen] = useState(false);

  const [stats, setStats] = useState<{ totalConversations: number; totalMessages: number; avgMessagesPerConv: number; mostActiveDay: string } | null>(null);
  const [statsLoading, setStatsLoading] = useState(false);
  const [online, setOnline] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Online/offline detection
  useEffect(() => {
    setOnline(navigator.onLine);
    const handleOnline = () => setOnline(true);
    const handleOffline = () => setOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Fetch stats when dialog opens
  useEffect(() => {
    if (statsOpen) {
      setStatsLoading(true);
      fetch('/api/chat/stats')
        .then((res) => {
          if (!res.ok) throw new Error('Stats fetch failed');
          return res.json();
        })
        .then((data) => {
          if (data.totalConversations !== undefined) {
            setStats(data);
          }
        })
        .catch(() => {
          // silently fail
        })
        .finally(() => setStatsLoading(false));
    }
  }, [statsOpen]);

  // Feature 5: Pinned conversations state - lazy init from localStorage
  const [pinnedIds, setPinnedIds] = useState<string[]>(() => {
    if (typeof window === 'undefined') return [];
    return getStoredPinned();
  });

  // Cleanup pinned IDs that no longer exist
  const convIds = useMemo(() => new Set(conversations.map((c) => c.id)), [conversations]);
 const validPinnedCount = pinnedIds.filter((id) => convIds.has(id)).length;
  useEffect(() => {
    if (validPinnedCount !== pinnedIds.length) {
      const cleaned = pinnedIds.filter((id) => convIds.has(id));
      savePinned(cleaned);
      // Use microtask to avoid the lint rule
      queueMicrotask(() => setPinnedIds(cleaned));
    }
  }, [validPinnedCount, pinnedIds, convIds]);

  // Select mode state
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showBulkDeleteDialog, setShowBulkDeleteDialog] = useState(false);
  const [isBulkDeleting, setIsBulkDeleting] = useState(false);

  const filteredConversations = conversations.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const hasAnyConversations = filteredConversations.length > 0;

  // Feature 5: Separate pinned and unpinned conversations
  const pinnedConversations = useMemo(() => {
    return filteredConversations.filter((c) => pinnedIds.includes(c.id));
  }, [filteredConversations, pinnedIds]);

  const unpinnedConversations = useMemo(() => {
    return filteredConversations.filter((c) => !pinnedIds.includes(c.id));
  }, [filteredConversations, pinnedIds]);

  const grouped = groupConversations(unpinnedConversations);

  // Feature 5: Toggle pin
  const handleTogglePin = useCallback((convId: string) => {
    setPinnedIds((prev) => {
      const isPinned = prev.includes(convId);
      const next = isPinned
        ? prev.filter((id) => id !== convId)
        : [...prev, convId];
      savePinned(next);
      toast.success(isPinned ? 'Unpinned' : 'Conversation pinned');
      return next;
    });
  }, []);

  const handleLogout = useCallback(async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    logout();
    setLogoutDialogOpen(false);
    toast.info('Signed out successfully');
  }, [logout]);

  const handleDelete = useCallback(async () => {
    if (!deleteTarget) return;
    try {
      await fetch(`/api/chat/${deleteTarget}/messages`, { method: 'DELETE' });
      deleteConversation(deleteTarget);
      setDeleteTarget(null);
      toast.success('Conversation deleted');
    } catch (error) {
      console.error('Failed to delete conversation:', error);
    }
  }, [deleteTarget, deleteConversation]);

  // Toggle selection for a single conversation
  const handleToggleSelect = useCallback((convId: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(convId)) {
        next.delete(convId);
      } else {
        next.add(convId);
      }
      return next;
    });
  }, []);

  // Toggle select all visible conversations
  const handleSelectAll = useCallback(() => {
    if (selectedIds.size === filteredConversations.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredConversations.map((c) => c.id)));
    }
  }, [selectedIds.size, filteredConversations]);

  // Exit select mode
  const handleExitSelectMode = useCallback(() => {
    setIsSelectMode(false);
    setSelectedIds(new Set());
  }, []);

  // Bulk delete selected conversations
  const handleBulkDelete = useCallback(async () => {
    setIsBulkDeleting(true);
    try {
      await Promise.all(
        Array.from(selectedIds).map((id) =>
          fetch(`/api/chat/${id}/messages`, { method: 'DELETE' })
        )
      );
      for (const id of selectedIds) {
        deleteConversation(id);
      }
      toast.success(`${selectedIds.size} conversation${selectedIds.size !== 1 ? 's' : ''} deleted`);
      setIsSelectMode(false);
      setSelectedIds(new Set());
      setShowBulkDeleteDialog(false);
    } catch (error) {
      console.error('Failed to delete conversations:', error);
      toast.error('Failed to delete some conversations');
    } finally {
      setIsBulkDeleting(false);
    }
  }, [selectedIds, deleteConversation]);

  const handleDuplicate = useCallback(
    async (convId: string) => {
      try {
        const res = await fetch(`/api/chat/${convId}/duplicate`, {
          method: 'POST',
        });
        if (!res.ok) return;
        const data = await res.json();
        if (data.conversation) {
          addConversation(data.conversation);
          toast.success('Conversation duplicated');
        }
      } catch (error) {
        console.error('Failed to duplicate conversation:', error);
      }
    },
    [addConversation]
  );

  const createNewChat = useCallback(async () => {
    try {
      const res = await fetch('/api/chat/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: 'New Chat' }),
      });
      if (!res.ok) return;
      const data = await res.json();
      if (data.conversation) {
        addConversation({
          ...data.conversation,
          messages: [],
        });
        toast.success('New conversation started');
      }
    } catch (error) {
      console.error('Failed to create conversation:', error);
    }
  }, [addConversation]);

  return (
    <>
      {/* Overlay backdrop */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            onClick={onClose}
          />
        )}
      </AnimatePresence>

      {/* Sidebar - hidden by default, slides in on toggle */}
      <motion.aside
        initial={false}
        animate={{
          x: isOpen ? 0 : -320,
        }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className={cn(
          'fixed left-0 top-0 z-50 h-full w-[85vw] max-w-[300px] sm:w-[300px] bg-card backdrop-blur-xl border-r border-border flex flex-col shadow-2xl shadow-black/20',
          'pt-[env(safe-area-inset-top)]'
        )}
      >
        {/* Network status banner - shown when offline */}
        <AnimatePresence>
          {!online && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="network-banner offline"
            >
              <div className="flex items-center gap-2 px-3 py-2 bg-amber-500/15 dark:bg-amber-500/10 border-b border-amber-500/20">
                <WifiOff className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                <span className="text-xs font-medium text-amber-700 dark:text-amber-300">You are offline</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Animated gradient separator (right edge) */}
        <div className="absolute top-0 right-0 bottom-0 w-px pointer-events-none z-10 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-500/20 to-transparent animate-pulse" />
        </div>

        {/* Header with gradient */}
        <div className="p-3 sm:p-4 border-b border-border bg-gradient-to-br from-purple-600/8 via-transparent to-purple-600/8 relative overflow-hidden">
          {/* Subtle background pattern */}
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)', backgroundSize: '16px 16px' }} />
          <div className="relative">
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <ZinterLogoWithText size="sm" textSize="base" className="flex-1" />
            <Button variant="ghost" size="icon" className="h-9 w-9 hover:scale-110 active:scale-95 transition-transform" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* User greeting */}
          
          {user && (
            <p className="text-xs sm:text-sm text-muted-foreground mb-2 sm:mb-3 pl-0.5">
              {getGreeting()}, <span className="font-medium text-foreground">{user.name}</span>
            </p>
          )}

          {/* Search with animated underline effect */}
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground/70 group-focus-within:text-purple-500 transition-all duration-300 group-focus-within:scale-110" />
            <div className="absolute bottom-0 left-3 right-3 h-[2px] bg-gradient-to-r from-purple-500/0 via-purple-500/0 to-purple-500/0 group-focus-within:from-purple-500/50 group-focus-within:via-purple-500/80 group-focus-within:to-purple-500/50 rounded-full transition-all duration-300" />
            <Input
              placeholder="Search conversations..."
              className="pl-9 h-9 text-sm bg-muted/40 border-transparent focus-visible:border-transparent focus-visible:bg-background focus-visible:shadow-none transition-all duration-300 placeholder:text-muted-foreground/50"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Select mode button */}
          {hasAnyConversations && (
            <Button
              variant={isSelectMode ? 'default' : 'ghost'}
              size="sm"
              className={cn(
                'w-full mt-2 gap-2 rounded-lg h-9 text-xs font-medium transition-all duration-200',
                isSelectMode
                  ? 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/30 hover:bg-purple-500/20'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted/60'
              )}
              onClick={() => {
                if (isSelectMode) {
                  handleExitSelectMode();
                } else {
                  setIsSelectMode(true);
                }
              }}
            >
              <CheckSquare className={cn('w-3.5 h-3.5', isSelectMode && 'text-purple-500')} />
              {isSelectMode ? 'Exit Select Mode' : 'Select Multiple'}
            </Button>
          )}
          </div>
        </div>

        {/* New Chat button with shimmer on hover */}
        <div className="px-3 pt-2 sm:pt-3 pb-1">
          <Button
            onClick={createNewChat}
            className="w-full justify-start gap-2.5 rounded-lg bg-gradient-to-r from-purple-500 to-purple-500 hover:from-purple-600 hover:to-purple-600 text-white shadow-sm shadow-purple-500/20 hover:shadow-md hover:shadow-purple-500/30 active:scale-[0.98] transition-all duration-200 h-9 sm:h-10 relative overflow-hidden group hover-lift-sm"
          >
            <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 shimmer" />
            <Plus className="w-4 h-4 relative z-10" />
            <span className="text-sm font-medium relative z-10">New Chat</span>
          </Button>
        </div>

        {/* Conversations list */}
        <ScrollArea className="flex-1 min-h-0 sidebar-scroll" ref={scrollRef}>
          <div className="p-2">
            <AnimatePresence mode="wait">
              {!hasAnyConversations ? (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="text-center py-16 px-4"
                >
                  <div className="relative w-16 h-16 mx-auto mb-4">
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-200 dark:from-purple-800/40 dark:to-purple-800/40 blur-sm" />
                    <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-100 to-purple-100 dark:from-purple-900/30 dark:to-purple-900/30 flex items-center justify-center shadow-inner">
                      <MessageSquare className="w-7 h-7 text-purple-500/60 animate-float" />
                    </div>
                  </div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">
                    No conversations yet
                  </p>
                  <p className="text-xs text-muted-foreground/70 leading-relaxed">
                    Click &quot;New Chat&quot; above to start<br />your first conversation
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="list"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  {/* Feature 5: Pinned section */}
                  {pinnedConversations.length > 0 && (
                    <div className="mb-2">
                      <div className="gradient-separator mx-3 mb-2 rounded-full" />
                      <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/60 px-3 pt-3 pb-1.5 flex items-center gap-1.5">
                        <Pin className="w-3 h-3" />
                        Pinned
                      </p>
                      {pinnedConversations.map((conv) => (
                        <ConversationItem
                          key={conv.id}
                          conversation={conv}
                          isActive={conv.id === activeConversationId}
                          isPinned={true}
                          isSelectMode={isSelectMode}
                          isSelected={selectedIds.has(conv.id)}
                          isAutoTiting={conv.id === autoTitleLoadingId}
                          onSelect={() => handleToggleSelect(conv.id)}
                          onClick={() => {
                            if (isSelectMode) {
                              handleToggleSelect(conv.id);
                            } else {
                              setActiveConversationId(conv.id);
                              onClose();
                            }
                          }}
                          onDelete={() => setDeleteTarget(conv.id)}
                          onRename={(newTitle) => {
                            updateConversation(conv.id, { title: newTitle });
                          }}
                          onTogglePin={() => handleTogglePin(conv.id)}
                          onDuplicate={() => handleDuplicate(conv.id)}
                        />
                      ))}
                    </div>
                  )}

                  {/* Unpinned conversations with time-based grouping */}
                  {TIME_GROUP_ORDER.map((group) => {
                    const groupConvs = grouped[group];
                    if (groupConvs.length === 0) return null;
                    return (
                      <div key={group} className="mb-2">
                        <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/60 px-3 pt-3 pb-1.5">
                          {group}
                        </p>
                        {groupConvs.map((conv) => (
                          <ConversationItem
                            key={conv.id}
                            conversation={conv}
                            isActive={conv.id === activeConversationId}
                            isPinned={false}
                            isSelectMode={isSelectMode}
                            isSelected={selectedIds.has(conv.id)}
                            isAutoTiting={conv.id === autoTitleLoadingId}
                            onSelect={() => handleToggleSelect(conv.id)}
                            onClick={() => {
                              if (isSelectMode) {
                                handleToggleSelect(conv.id);
                              } else {
                                setActiveConversationId(conv.id);
                                onClose();
                              }
                            }}
                            onDelete={() => setDeleteTarget(conv.id)}
                            onRename={(newTitle) => {
                              updateConversation(conv.id, { title: newTitle });
                            }}
                            onTogglePin={() => handleTogglePin(conv.id)}
                            onDuplicate={() => handleDuplicate(conv.id)}
                          />
                        ))}
                      </div>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          {/* Bottom gradient fade */}
          <div className="gradient-fade-bottom pointer-events-none" style={{ height: '2px' }} />
        </ScrollArea>

        {/* Floating select mode action bar */}
        <AnimatePresence>
          {isSelectMode && selectedIds.size > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className="absolute bottom-0 left-0 right-0 z-20 p-3"
            >
              <div className="rounded-xl border border-purple-500/30 bg-background/95 backdrop-blur-xl shadow-lg shadow-purple-500/10 p-3 flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 text-xs gap-1.5 text-muted-foreground hover:text-foreground"
                  onClick={handleSelectAll}
                >
                  <CheckSquare className={cn('w-3.5 h-3.5', selectedIds.size === filteredConversations.length && 'text-purple-500')} />
                  {selectedIds.size === filteredConversations.length ? 'Deselect All' : 'Select All'}
                </Button>
                <div className="flex-1 text-center">
                  <span className="text-xs font-medium text-purple-600 dark:text-purple-400">
                    {selectedIds.size} selected
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 text-xs gap-1.5 text-muted-foreground hover:text-foreground"
                  onClick={handleExitSelectMode}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  className="h-8 text-xs gap-1.5"
                  onClick={() => setShowBulkDeleteDialog(true)}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer */}
        <div className="p-3 border-t border-border/40 bg-gradient-to-t from-muted/30 to-transparent space-y-2 gradient-border-top pb-[max(1rem,env(safe-area-inset-bottom))]">
          {user && (
            <motion.button
              type="button"
              className="flex items-center gap-3 px-2.5 sm:px-3 py-2 sm:py-2.5 rounded-xl bg-muted/50 hover:bg-muted/70 transition-colors duration-200 w-full text-left shadow-sm border border-border/20"
              whileHover={{ x: 2 }}
              onClick={() => setProfileDialogOpen(true)}
            >
              <div className={cn('relative', online ? 'status-online' : 'status-offline')}>
                <div className={cn(
                  'w-8 h-8 rounded-full text-white flex items-center justify-center text-xs font-bold shadow-sm bg-gradient-to-br from-purple-500 to-purple-600'
                )}>
                  {user.name.charAt(0).toUpperCase()}
                </div>
                {/* Online/offline status dot */}
                <div className={cn(
                  'absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-background transition-colors duration-300',
                  online ? 'bg-purple-500' : 'bg-amber-500'
                )} />
                {/* Pulsing ring */}
                <div className="absolute -inset-0.5 rounded-full animate-pulse-ring" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user.name}</p>
                <p className="text-[11px] text-muted-foreground truncate">{user.email}</p>
              </div>
              <UserCircle className="w-4 h-4 text-muted-foreground/50 shrink-0" />
            </motion.button>
          )}
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-10 w-10 sm:h-8 sm:w-8 text-muted-foreground hover:text-foreground hover:bg-muted/60 hover:scale-105 active:scale-95 transition-all duration-150"
              onClick={() => setStatsOpen(true)}
              title="Statistics"
            >
              <BarChart3 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-10 w-10 sm:h-8 sm:w-8 text-muted-foreground hover:text-foreground hover:bg-muted/60 hover:scale-105 active:scale-95 transition-all duration-150"
              onClick={() => setProfileDialogOpen(true)}
              title="Profile & Settings"
            >
              <Settings className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-10 w-10 sm:h-8 sm:w-8 text-muted-foreground hover:text-foreground hover:bg-muted/60 hover:scale-105 active:scale-95 transition-all duration-150"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              suppressHydrationWarning
              title={theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
            >
              <Sun className="w-3.5 h-3.5 rotate-0 scale-100 transition-transform duration-500 dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute w-3.5 h-3.5 rotate-90 scale-0 transition-transform duration-500 dark:rotate-0 dark:scale-100" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-10 w-10 sm:h-8 sm:w-8 text-destructive/80 hover:text-destructive hover:bg-destructive/10 hover:scale-105 active:scale-95 transition-all duration-150"
              onClick={() => setLogoutDialogOpen(true)}
              title="Sign Out"
            >
              <LogOut className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </motion.aside>

      {/* Delete confirmation dialog */}
      <Dialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Conversation</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this conversation? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Logout confirmation dialog */}
      <Dialog open={logoutDialogOpen} onOpenChange={setLogoutDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Sign Out</DialogTitle>
            <DialogDescription>
              Are you sure you want to sign out? You will need to log in again to access your conversations.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setLogoutDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleLogout}>
              Sign Out
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk delete confirmation dialog */}
      <Dialog open={showBulkDeleteDialog} onOpenChange={setShowBulkDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Selected Conversations</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {selectedIds.size} selected conversation{selectedIds.size !== 1 ? 's' : ''}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBulkDeleteDialog(false)} disabled={isBulkDeleting}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleBulkDelete} disabled={isBulkDeleting}>
              {isBulkDeleting ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete All Selected'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Statistics dialog */}
      <Dialog open={statsOpen} onOpenChange={setStatsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center">
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              Conversation Statistics
            </DialogTitle>
            <DialogDescription>Your chat activity at a glance</DialogDescription>
          </DialogHeader>
          {statsLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-purple-500" />
            </div>
          ) : stats ? (
            <div className="grid grid-cols-2 gap-2 sm:gap-3">
              <div className="rounded-xl border border-border/60 bg-gradient-to-br from-purple-500/5 to-purple-500/5 p-4 text-center">
                <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-purple-500/10 flex items-center justify-center">
                  <MessageSquare className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                </div>
                <p className="text-2xl font-bold text-foreground">{stats.totalConversations}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Conversations</p>
              </div>
              <div className="rounded-xl border border-border/60 bg-gradient-to-br from-purple-500/5 to-cyan-500/5 p-4 text-center">
                <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-purple-500/10 flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                </div>
                <p className="text-2xl font-bold text-foreground">{stats.totalMessages}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Messages</p>
              </div>
              <div className="rounded-xl border border-border/60 bg-gradient-to-br from-amber-500/5 to-orange-500/5 p-4 text-center">
                <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-amber-500/10 flex items-center justify-center">
                  <Hash className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                </div>
                <p className="text-2xl font-bold text-foreground">{stats.avgMessagesPerConv}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Avg. Messages/Conv</p>
              </div>
              <div className="rounded-xl border border-border/60 bg-gradient-to-br from-violet-500/5 to-pink-500/5 p-4 text-center">
                <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-violet-500/10 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-violet-600 dark:text-violet-400" />
                </div>
                <p className="text-sm font-bold text-foreground leading-tight mt-1">{stats.mostActiveDay}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Most Active Day</p>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground">No statistics available</p>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Profile & Settings sheet */}
      <UserProfileSheet open={profileDialogOpen} onOpenChange={setProfileDialogOpen} />
    </>
  );
}

function ConversationItem({
  conversation,
  isActive,
  isPinned,
  isSelectMode,
  isSelected,
  isAutoTiting,
  onSelect,
  onClick,
  onDelete,
  onRename,
  onTogglePin,
  onDuplicate,
}: {
  conversation: Conversation;
  isActive: boolean;
  isPinned: boolean;
  isSelectMode?: boolean;
  isSelected?: boolean;
  isAutoTiting?: boolean;
  onSelect?: () => void;
  onClick: () => void;
  onDelete: () => void;
  onRename: (newTitle: string) => void;
  onTogglePin: () => void;
  onDuplicate: () => void;
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(conversation.title);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  const handleDoubleClick = useCallback(() => {
    setIsEditing(true);
    setEditValue(conversation.title);
  }, [conversation.title]);

  const handleRenameSubmit = useCallback(async () => {
    const trimmed = editValue.trim();
    if (trimmed && trimmed !== conversation.title) {
      try {
        const res = await fetch(`/api/chat/${conversation.id}/messages`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title: trimmed }),
        });
        if (res.ok) {
          onRename(trimmed);
          toast.success('Conversation renamed');
        }
      } catch (error) {
        console.error('Failed to rename conversation:', error);
      }
    }
    setIsEditing(false);
  }, [editValue, conversation.title, conversation.id, onRename]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
        handleRenameSubmit();
      } else if (e.key === 'Escape') {
        setIsEditing(false);
        setEditValue(conversation.title);
      }
    },
    [handleRenameSubmit, conversation.title]
  );

  const lastMessage = conversation.messages[conversation.messages.length - 1];
  const previewText = lastMessage
    ? lastMessage.content.slice(0, 50) + (lastMessage.content.length > 50 ? '...' : '')
    : 'No messages yet';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -100, transition: { duration: 0.2 } }}
      className="group"
      whileHover={{ y: -1 }}
      transition={{ type: 'spring', stiffness: 400, damping: 25 }}
    >
      <div
        className={cn(
          'flex items-center gap-1 rounded-lg text-sm transition-all duration-200',
          'hover:bg-accent/80 hover:shadow-md hover:shadow-purple-500/8 active:scale-[0.99] hover-lift',
          isPinned && !isActive && 'bg-muted/30',
          isActive
            ? 'bg-accent text-accent-foreground border-l-[3px] border-l-purple-500 shadow-sm shadow-purple-500/10'
            : 'border-l-[3px] border-l-transparent',
          isSelectMode && isSelected && 'bg-purple-500/10 border-l-purple-500',
          isSelectMode && 'cursor-pointer'
        )}
      >
        {/* Clickable conversation content */}
        <button
          onClick={onClick}
          onDoubleClick={!isSelectMode ? handleDoubleClick : undefined}
          className="flex-1 text-left p-3 min-w-0"
        >
          <div className="flex items-start gap-2.5">
            {/* Select mode checkbox */}
            {isSelectMode && (
              <div className="flex items-center justify-center mt-0.5 shrink-0">
                <div
                  className={cn(
                    'w-4 h-4 rounded border-2 flex items-center justify-center transition-all duration-150',
                    isSelected
                      ? 'bg-purple-500 border-purple-500'
                      : 'border-muted-foreground/40 hover:border-purple-500/60'
                  )}
                >
                  {isSelected && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
                </div>
              </div>
            )}
            <MessageSquare
              className={cn(
                'w-4 h-4 mt-0.5 shrink-0 transition-colors',
                isActive ? 'text-purple-500' : 'text-muted-foreground/60'
              )}
            />
            <div className="flex-1 min-w-0">
              {isEditing ? (
                <Input
                  ref={inputRef}
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  onBlur={handleRenameSubmit}
                  onKeyDown={handleKeyDown}
                  onClick={(e) => e.stopPropagation()}
                  className="h-6 text-sm px-1 py-0 border-purple-500/50 focus-visible:ring-purple-500/30"
                  maxLength={100}
                />
              ) : isAutoTiting ? (
                <Skeleton className="h-4 w-28 rounded" />
              ) : (
                <p className="font-medium truncate flex items-center gap-1.5">
                  {conversation.title}
                  {isPinned && (
                    <Pin className="w-3 h-3 text-amber-500 fill-current shrink-0" />
                  )}
                </p>
              )}
              <p className="text-xs text-muted-foreground/70 mt-0.5 truncate">{previewText}</p>
            </div>
          </div>
        </button>

        {/* Delete button - always visible */}
        {!isEditing && !isSelectMode && (
          <div className="shrink-0 pr-1.5">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground/60 hover:text-destructive hover:bg-destructive/10 hover:scale-110 active:scale-95 transition-all duration-150"
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              title="Delete conversation"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        )}
      </div>
    </motion.div>
  );
}
